please note that some of these apps are broken/unfinished!! i have
better things to do in life (like making more games) so i probably
wont be updating/changing these (also to keep them in their original
state).

if you want, learn ti basic and edit it yourself to fix it!!
if you actually learned ti basic just to fix the programs, you should definetely tell me by contributing to github or something (i dont really know how github works i could be entirely wrong) or just post it on internet archive or something

if you want to run these files, use ti connect ce (not ti connect) to send them to your calculator.

alteratively, use an emulator like CEmu.

have fun!!
