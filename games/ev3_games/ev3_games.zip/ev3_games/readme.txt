to get these onto the ev3, i used the ev3 explorer from ev3basic (i only know basic)

you can use an emulator if there is one

have fun!!!
