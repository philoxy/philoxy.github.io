--Philooxy's JellyCar Worlds Levels!--
V1 - April 1st 2026
this isnt an april fools joke i swear

these levels were made for jellycar worlds, a game which you can buy on steam here for only $8.99!: https://store.steampowered.com/app/1740930/JellyCar_Worlds/

how 2 install
1. find the jellycar worlds user data directory
    on windows:
C:\Users\<username>\AppData\LocalLow\Walaber\JellyCar Worlds\<some big number>\CustomLevels\
    linux: idk lol
    mac: who games on a mac?? i mean i do but
2. put the files inside that directory
3. open up jellycar worlds, go to custom levels, and enjoy!

about the levels
    cartest - i tried (and failed) to make a clone car
    ice volcano - one of my actual levels!!! i think my 2nd
    how to ability - my attempt at a tutorial, which is probably way too hard considering it was made with my skill level. youre probably better off finishing the campaign instead
    geometry dash - my recreation of geometry dash that was unfinished
    claw_machine_v2.jcwlvl - wow, a claw machine!!
    plane_flip.jcwlvl - the name speaks for itself
    jumping test - platformer attempt
    bouncy2 - most recent level i just started that i shoved in here because why not (not like im going to work on these for another 4 months lol)


id recommend only playing ice volcano, how to ability, and claw_machine_v2.jcwlvl, as those are my actual levels (the rest are unfinished/tests)

have fun!!

theres a secret 4th level i have finished, but thats on another pc and i have to transfer it. stay tuned for it!!
