to get these onto the ev3, i used the ev3 explorer from ev3basic
(yes i made this in basic, its the only language i know T-T)

alternatively, use an emulator (sorry, i dont know any)

have fun!!!

also, i might remake etg (the rhythm game i made for the ti 84+) for
this thing, so keep checking every single 27.63 seconds!! (it will include more features like audio, because the calculator doesnt have that)
