install all of the needed apps!!!* you need them for some features to function properly, like the credits and about section.
otherwise enjoy!!

to get them on the ti 83, use ti connect (not ti connect ce!)

alternatively, you can use an emulator, like jstified

*i think you can just install STRVIEWER, THVI, and THVI2, the rest are older versions.
